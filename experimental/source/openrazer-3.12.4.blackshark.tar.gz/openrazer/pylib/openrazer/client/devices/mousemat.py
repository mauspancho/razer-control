# SPDX-License-Identifier: GPL-2.0-or-later

from openrazer.client.devices import RazerDevice as __RazerDevice


class RazerMousemat(__RazerDevice):
    def trigger_reactive(self) -> None:
        """
        Trigger a reactive flash
        """
        self._dbus_interfaces['device'].triggerReactive()
